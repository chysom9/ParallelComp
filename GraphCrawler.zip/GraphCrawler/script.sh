#!/bin/bash
make
./graph_crawler "Tom Hanks" 2
